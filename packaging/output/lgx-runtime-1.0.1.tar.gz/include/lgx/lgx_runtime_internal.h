/**
 * LGX Runtime Internal Header
 * 
 * Internal structures and interfaces for the LGX Runtime Core.
 * This header is NOT part of the public API.
 */

#ifndef LGX_RUNTIME_INTERNAL_H
#define LGX_RUNTIME_INTERNAL_H

#include "lgx_runtime.h"
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>      // For FILE*
#include <sys/types.h>  // For ssize_t
#include <limits.h>     // For PATH_MAX

#ifdef __cplusplus
extern "C" {
#endif

// Error callback type (internal - different from public API)
typedef void (*lgx_internal_error_callback_t)(lgx_result_t error, const char* message, 
                                              const char* recovery_guidance, void* user_data);

// Runtime configuration structure (internal definition)
struct lgx_runtime_config {
    size_t memory_pool_size;
    const char* log_path;
    uint32_t flags;
    size_t frame_arena_size;      // Task 3.4.5.2.1
    size_t frame_arena_max_size;  // Task 3.4.5.2.2
};

// Forward declarations for subsystem handles
typedef struct lgx_memory_manager lgx_memory_manager_t;
typedef struct lgx_hardware_adapter lgx_hardware_adapter_t;
typedef struct lgx_capability_detector lgx_capability_detector_t;
typedef struct lgx_lifecycle_manager lgx_lifecycle_manager_t;
typedef struct lgx_platform_services lgx_platform_services_t;
typedef struct lgx_telemetry lgx_telemetry_t;
typedef struct lgx_telemetry_process lgx_telemetry_process_t;
typedef struct lgx_error_handler lgx_error_handler_t;
typedef struct lgx_health_monitor lgx_health_monitor_t;

// Configuration flags
#define LGX_CONFIG_ENABLE_TELEMETRY     (1 << 0)
#define LGX_CONFIG_ENABLE_DEBUG_LOGGING (1 << 1)
#define LGX_CONFIG_STRICT_VALIDATION    (1 << 2)

// Global runtime state
typedef struct lgx_runtime_state {
    bool initialized;
    pthread_mutex_t mutex;
    
    // Configuration
    const lgx_runtime_config_t* config;
    
    // Subsystem handles
    lgx_memory_manager_t* memory_manager;
    lgx_hardware_adapter_t* hardware_adapter;
    lgx_capability_detector_t* capability_detector;
    lgx_lifecycle_manager_t* lifecycle_manager;
    lgx_platform_services_t* platform_services;
    lgx_telemetry_t* telemetry;
    lgx_error_handler_t* error_handler;
    lgx_health_monitor_t* health_monitor;
} lgx_runtime_state_t;

// Internal API functions
lgx_runtime_state_t* lgx_runtime_get_state(void);
bool lgx_runtime_is_initialized(void);

// Subsystem initialization functions
lgx_result_t lgx_memory_manager_init(lgx_memory_manager_t** manager, 
                                    const lgx_runtime_config_t* config,
                                    lgx_hardware_adapter_t* hardware_adapter);
lgx_result_t lgx_memory_manager_shutdown(lgx_memory_manager_t* manager);

// Memory manager API functions
void* lgx_memory_manager_alloc(lgx_memory_manager_t* manager, size_t size, 
                              const lgx_allocation_intent_base_t* intent);
void lgx_memory_manager_free(lgx_memory_manager_t* manager, void* ptr);
void* lgx_memory_manager_alloc_aligned(lgx_memory_manager_t* manager, size_t size, 
                                      size_t alignment, const lgx_allocation_intent_base_t* intent);
void* lgx_memory_manager_alloc_with_intent_ex(lgx_memory_manager_t* manager, 
                                             const void* intent, size_t intent_type_id);
lgx_result_t lgx_memory_manager_get_stats(lgx_memory_manager_t* manager, lgx_memory_stats_t* stats);
lgx_result_t lgx_memory_manager_get_usage_stats(lgx_memory_manager_t* manager, void* ptr, 
                                               lgx_allocation_usage_t* usage);
lgx_result_t lgx_memory_manager_validate_intent(lgx_memory_manager_t* manager, void* ptr);

// Hardware adapter API functions
bool lgx_hardware_adapter_has_huge_pages(lgx_hardware_adapter_t* adapter);
bool lgx_hardware_adapter_has_numa(lgx_hardware_adapter_t* adapter);
long lgx_hardware_adapter_get_cpu_count(lgx_hardware_adapter_t* adapter);
bool lgx_hardware_adapter_has_gpu(lgx_hardware_adapter_t* adapter);
const char* lgx_hardware_adapter_get_gpu_vendor(lgx_hardware_adapter_t* adapter);
const char* lgx_hardware_adapter_get_driver_version(lgx_hardware_adapter_t* adapter);

// Huge pages API functions (Day 10 Optimization)
lgx_result_t lgx_hugepages_init(lgx_hardware_adapter_t* hardware_adapter);
lgx_result_t lgx_hugepages_shutdown(void);
void* lgx_hugepages_alloc(size_t size);
void lgx_hugepages_free(void* ptr, size_t size);
void* lgx_hugepages_alloc_selective(size_t size, bool is_long_lived, bool is_hot_path);
bool lgx_hugepages_available(void);
double lgx_hugepages_estimate_tlb_improvement(size_t memory_size);
lgx_hardware_status_t lgx_hardware_adapter_get_status(lgx_hardware_adapter_t* adapter);

// Intent allocator API functions (Task 3.4)
lgx_result_t lgx_intent_allocator_init(void);
lgx_result_t lgx_intent_allocator_shutdown(void);
// lgx_intent_stats_t and lgx_intent_get_stats are now in lgx_runtime.h

// Capability detector API functions
bool lgx_capability_detector_has_capability(lgx_capability_detector_t* detector, 
                                           const char* capability_name);
bool lgx_capability_detector_has_capability_enum(lgx_capability_detector_t* detector, 
                                                lgx_capability_t capability);
uint32_t lgx_capability_detector_get_capability_version(lgx_capability_detector_t* detector,
                                                       const char* capability_name);
lgx_result_t lgx_capability_detector_query_capabilities(lgx_capability_detector_t* detector,
                                                       uint32_t* capabilities);

// Lifecycle manager API functions
lgx_result_t lgx_lifecycle_manager_suspend(lgx_lifecycle_manager_t* manager);
lgx_result_t lgx_lifecycle_manager_resume(lgx_lifecycle_manager_t* manager);

// Platform services API functions
int lgx_platform_services_fs_open(lgx_platform_services_t* services, 
                                  const char* path, int flags);
ssize_t lgx_platform_services_fs_read(lgx_platform_services_t* services,
                                     int fd, void* buffer, size_t size);
ssize_t lgx_platform_services_fs_write(lgx_platform_services_t* services,
                                      int fd, const void* buffer, size_t size);
int lgx_platform_services_fs_close(lgx_platform_services_t* services, int fd);
uint64_t lgx_platform_services_time_now_ns(lgx_platform_services_t* services);
lgx_result_t lgx_platform_services_time_sleep_ms(lgx_platform_services_t* services,
                                                 uint32_t milliseconds);

// Error handler API functions
lgx_result_t lgx_error_handler_set_error(lgx_error_handler_t* handler,
                                        lgx_result_t error,
                                        const char* function,
                                        const char* file,
                                        int line);
lgx_result_t lgx_error_handler_get_last_error(lgx_error_handler_t* handler);
lgx_result_t lgx_error_handler_get_last_error_ex(lgx_error_handler_t* handler,
                                                char* message_buffer, size_t message_size,
                                                char* recovery_buffer, size_t recovery_size);

// Health monitor API functions
lgx_result_t lgx_health_monitor_check(lgx_health_monitor_t* monitor,
                                     lgx_health_status_t* status);
lgx_health_status_t lgx_health_monitor_get_status(lgx_health_monitor_t* monitor);

// Health monitoring with alerts (Task 14.3.3) - Internal functions
lgx_result_t lgx_health_monitor_start_monitoring(lgx_health_monitor_t* monitor, uint32_t interval_ms);
lgx_result_t lgx_health_monitor_stop_monitoring(lgx_health_monitor_t* monitor);
bool lgx_health_monitor_is_monitoring_running(lgx_health_monitor_t* monitor);
void lgx_health_monitor_set_alert_callback(lgx_health_monitor_t* monitor,
                                           lgx_health_alert_callback_t callback, void* user_data);
void lgx_health_monitor_set_thresholds(lgx_health_monitor_t* monitor,
                                       float memory_warning, float memory_critical,
                                       float cpu_warning, float cpu_critical);
lgx_result_t lgx_health_monitor_get_monitoring_stats(lgx_health_monitor_t* monitor,
                                                     uint64_t* total_checks,
                                                     uint64_t* warnings, uint64_t* criticals);

// Public API wrappers
lgx_result_t lgx_health_monitoring_start_public(uint32_t interval_ms);
lgx_result_t lgx_health_monitoring_stop_public(void);
bool lgx_health_monitoring_is_running_public(void);
void lgx_health_set_alert_callback_public(lgx_health_alert_callback_t callback, void* user_data);
void lgx_health_set_thresholds_public(float memory_warning, float memory_critical,
                                      float cpu_warning, float cpu_critical);
lgx_result_t lgx_health_get_monitoring_stats_public(uint64_t* total_checks,
                                                    uint64_t* warnings, uint64_t* criticals);

// Telemetry API functions
lgx_result_t lgx_telemetry_enable(lgx_telemetry_t* telemetry, bool user_consent);
lgx_result_t lgx_telemetry_record_frame_time(lgx_telemetry_t* telemetry, float frame_time_ms);
lgx_result_t lgx_telemetry_record_memory_usage(lgx_telemetry_t* telemetry, 
                                              size_t memory_usage_mb, size_t pool_usage_mb);
lgx_result_t lgx_telemetry_export(lgx_telemetry_t* telemetry, const char* output_path);

// Telemetry process API functions (Section 7.1)
lgx_result_t lgx_telemetry_process_init(lgx_telemetry_process_t** process);
lgx_result_t lgx_telemetry_process_shutdown(lgx_telemetry_process_t* process);
lgx_result_t lgx_telemetry_process_record_frame_time(lgx_telemetry_process_t* process, float frame_time_ms);
lgx_result_t lgx_telemetry_process_record_memory(lgx_telemetry_process_t* process, size_t memory_mb);
lgx_result_t lgx_telemetry_process_record_allocation(lgx_telemetry_process_t* process, size_t size);
uint64_t lgx_telemetry_process_get_dropped_events(lgx_telemetry_process_t* process);

// Lock-free pool API functions (Day 1-2 Breakthrough Optimization)
#define NUM_SIZE_CLASSES 16

lgx_result_t lgx_lockfree_pool_init(const size_t* size_classes, int num_classes);
lgx_result_t lgx_lockfree_pool_shutdown(void);
void lgx_lockfree_push(int size_class, void* ptr);
void* lgx_lockfree_pop(int size_class);
int lgx_lockfree_pop_batch(int size_class, void** blocks, int max_count);
void lgx_lockfree_push_batch(int size_class, void** blocks, int count);
uint32_t lgx_lockfree_pool_get_count(int size_class);
lgx_result_t lgx_lockfree_pool_prewarm(int size_class, int num_blocks);

// SIMD operations API functions (Day 8-9 Breakthrough Optimization)
void lgx_simd_detect_features(void);
bool lgx_simd_has_avx2(void);
int lgx_simd_find_nonempty_slot(void** slots, int count);
bool lgx_simd_all_null(void** slots, int count);
int lgx_simd_count_nonempty(void** slots, int count);

// Frame arena API functions (Month 1 - Specialized Allocators)
typedef struct {
    uint64_t total_allocations;
    uint64_t total_bytes_allocated;
    uint64_t overflow_count;
    uint64_t fallback_count;        // Number of times we fell back to persistent heap
    uint64_t fallback_bytes;        // Total bytes allocated via fallback
    uint64_t peak_usage_bytes;
    uint64_t current_frame;
} frame_arena_stats_t;

lgx_result_t lgx_frame_arena_init(void);
lgx_result_t lgx_frame_arena_shutdown(void);
void lgx_frame_arena_set_config_size(size_t size);  // Task 3.4.5.2.1
void lgx_frame_arena_set_config_max_size(size_t size);  // Task 3.4.5.2.2

// Internal function with call site tracking (Task 3.4.5.1.3)
// Always available for testing and debugging
void* lgx_frame_alloc_internal(size_t size, const char* file, int line);

// Tagged allocation function (Task 3.4.5.4.3)
void* lgx_frame_alloc_tagged_internal(size_t size, const char* tag, const char* file, int line);

// Public API - use macro to capture call site automatically in debug builds
#ifndef NDEBUG
// Debug build: macro captures file/line automatically
#define lgx_frame_alloc(size) lgx_frame_alloc_internal((size), __FILE__, __LINE__)
#define lgx_frame_alloc_tagged(size, tag) lgx_frame_alloc_tagged_internal((size), (tag), __FILE__, __LINE__)
#else
// Release build: regular function (no overhead)
void* lgx_frame_alloc(size_t size);
#define lgx_frame_alloc_tagged(size, tag) lgx_frame_alloc_tagged_internal((size), (tag), "unknown", 0)
#endif

lgx_result_t lgx_frame_reset(void);
lgx_result_t lgx_frame_get_stats(frame_arena_stats_t* stats);
bool lgx_frame_arena_is_initialized(void);
uint32_t lgx_frame_get_current_frame(void);
size_t lgx_frame_get_current_usage(void);
size_t lgx_frame_get_peak_usage(void);
bool lgx_frame_is_frame_pointer(void* ptr);
void lgx_frame_arena_dump_stats(FILE* output);  // Task 3.4.5.1 - dump detailed stats
size_t lgx_frame_arena_get_recommended_size(void);  // Task 3.4.5.2.3 - size recommendation
lgx_result_t lgx_frame_arena_dump(const char* output_path);  // Task 3.4.5.4.1 - export allocation map

// Profiler integration (Task 3.4.5.4.4)
lgx_result_t lgx_frame_arena_enable_tracy(bool enabled);
lgx_result_t lgx_frame_arena_enable_optick(bool enabled);
lgx_result_t lgx_frame_arena_enable_chrome_trace(bool enabled, const char* output_path);

// GPU memory pool API functions (Month 2 - Specialized Allocators)
// Forward declare Vulkan types to avoid requiring vulkan.h in this header
typedef struct VkInstance_T* VkInstance;
typedef struct VkPhysicalDevice_T* VkPhysicalDevice;
typedef struct VkDevice_T* VkDevice;
typedef struct VkDeviceMemory_T* VkDeviceMemory;
typedef uint64_t VkDeviceSize;
typedef uint32_t VkMemoryPropertyFlags;

typedef enum {
    LGX_GPU_DEVICE_LOCAL = 0,
    LGX_GPU_HOST_VISIBLE = 1,
    LGX_GPU_HOST_CACHED  = 2,
    LGX_GPU_MEMORY_TYPE_COUNT = 3
} lgx_gpu_memory_type_t;

typedef struct lgx_gpu_allocation lgx_gpu_allocation_t;

lgx_result_t lgx_gpu_pool_init(VkInstance instance, VkPhysicalDevice physical_device, VkDevice device);
lgx_result_t lgx_gpu_pool_shutdown(void);
bool lgx_gpu_pool_is_initialized(void);
bool lgx_gpu_pool_is_memory_type_available(lgx_gpu_memory_type_t type);
VkDeviceSize lgx_gpu_pool_get_memory_budget(lgx_gpu_memory_type_t type);
VkDeviceSize lgx_gpu_pool_get_memory_used(lgx_gpu_memory_type_t type);

// Buddy allocator API (Task 3.2.2 & 3.2.3)
lgx_gpu_allocation_t* lgx_gpu_alloc(VkDeviceSize size, VkDeviceSize alignment, lgx_gpu_memory_type_t type);
void lgx_gpu_free(lgx_gpu_allocation_t* alloc);
VkDeviceMemory lgx_gpu_get_memory(lgx_gpu_allocation_t* alloc);
VkDeviceSize lgx_gpu_get_offset(lgx_gpu_allocation_t* alloc);
VkDeviceSize lgx_gpu_get_size(lgx_gpu_allocation_t* alloc);
void* lgx_gpu_get_mapped_ptr(lgx_gpu_allocation_t* alloc);
float lgx_gpu_pool_get_fragmentation(lgx_gpu_memory_type_t type);
VkDeviceSize lgx_gpu_pool_get_peak_usage(lgx_gpu_memory_type_t type);

// GPU capability detection API (Task 3.5.2.3)
// GPU capability structure
typedef struct lgx_gpu_capabilities {
    bool supports_device_local;      // Device-only memory (fastest)
    bool supports_host_visible;      // CPU-accessible memory
    bool supports_host_cached;       // Cached host-visible memory
    bool supports_host_coherent;     // Coherent host-visible memory
    bool supports_resizable_bar;     // ReBAR (large host-visible memory)
    size_t max_device_local_mb;      // How much VRAM available
    size_t max_host_visible_mb;      // How much host-visible available
    uint32_t device_local_heap_index;
    uint32_t host_visible_heap_index;
} lgx_gpu_capabilities_t;

// GPU allocation strategy
typedef enum lgx_gpu_allocation_strategy {
    LGX_GPU_STRATEGY_DEVICE_LOCAL = 0,   // Fastest, GPU-only
    LGX_GPU_STRATEGY_HOST_VISIBLE = 1,   // Slower, CPU-accessible
    LGX_GPU_STRATEGY_RESIZABLE_BAR = 2,  // ReBAR: Large host-visible
    LGX_GPU_STRATEGY_FALLBACK = 3,       // Minimum viable
} lgx_gpu_allocation_strategy_t;

lgx_result_t lgx_gpu_detect_capabilities(VkPhysicalDevice physical_device, 
                                         lgx_gpu_capabilities_t* caps);
lgx_gpu_allocation_strategy_t lgx_gpu_select_strategy(const lgx_gpu_capabilities_t* caps);
size_t lgx_gpu_get_recommended_pool_size(lgx_gpu_allocation_strategy_t strategy,
                                         const lgx_gpu_capabilities_t* caps);
VkMemoryPropertyFlags lgx_gpu_get_memory_type_flags(lgx_gpu_allocation_strategy_t strategy);
void lgx_gpu_print_capabilities(const lgx_gpu_capabilities_t* caps);
void lgx_gpu_print_strategy(lgx_gpu_allocation_strategy_t strategy);

// Persistent heap API functions (Month 3 - Specialized Allocators)
typedef struct {
    uint64_t total_allocations;
    uint64_t total_frees;
    uint64_t active_allocations;
    uint64_t current_bytes;
    uint64_t peak_bytes;
    float fragmentation_ratio;
} lgx_heap_stats_t;

lgx_result_t lgx_persistent_heap_init(void);
lgx_result_t lgx_persistent_heap_shutdown(void);
void* lgx_heap_alloc(size_t size);
void lgx_heap_free(void* ptr);
bool lgx_heap_is_heap_pointer(void* ptr);
bool lgx_persistent_heap_is_initialized(void);
lgx_result_t lgx_heap_get_stats(lgx_heap_stats_t* stats);
float lgx_heap_get_fragmentation(void);
uint64_t lgx_heap_defragment(uint64_t time_budget_ns);
float lgx_heap_get_defrag_progress(void);
int lgx_heap_health_check(void);
void lgx_heap_get_error_stats(uint64_t* oom_errors, uint64_t* rate_limit_errors, 
                               uint64_t* validation_errors);

// Utility functions
uint64_t lgx_time_now_ns(void);

lgx_result_t lgx_hardware_adapter_init(lgx_hardware_adapter_t** adapter);
lgx_result_t lgx_hardware_adapter_shutdown(lgx_hardware_adapter_t* adapter);

lgx_result_t lgx_capability_detector_init(lgx_capability_detector_t** detector,
                                         lgx_hardware_adapter_t* hardware_adapter);
lgx_result_t lgx_capability_detector_shutdown(lgx_capability_detector_t* detector);

lgx_result_t lgx_lifecycle_manager_init(lgx_lifecycle_manager_t** manager);
lgx_result_t lgx_lifecycle_manager_shutdown(lgx_lifecycle_manager_t* manager);

lgx_result_t lgx_platform_services_init(lgx_platform_services_t** services,
                                       const lgx_runtime_config_t* config);
lgx_result_t lgx_platform_services_shutdown(lgx_platform_services_t* services);

lgx_result_t lgx_telemetry_init(lgx_telemetry_t** telemetry,
                               const lgx_runtime_config_t* config);
lgx_result_t lgx_telemetry_shutdown(lgx_telemetry_t* telemetry);

lgx_result_t lgx_error_handler_init(lgx_error_handler_t** handler);
lgx_result_t lgx_error_handler_shutdown(lgx_error_handler_t* handler);

lgx_result_t lgx_health_monitor_init(lgx_health_monitor_t** monitor,
                                    lgx_runtime_state_t* runtime_state);
lgx_result_t lgx_health_monitor_shutdown(lgx_health_monitor_t* monitor);

// Memory monitoring API functions (Task 12.2.4)
lgx_result_t lgx_memory_monitor_init(void);
lgx_result_t lgx_memory_monitor_shutdown(void);
void lgx_memory_monitor_update(void);
void lgx_memory_monitor_report_frame_arena(size_t bytes);
void lgx_memory_monitor_report_gpu_pool(size_t bytes);
void lgx_memory_monitor_report_persistent_heap(size_t bytes);
void lgx_memory_monitor_print_report(void);

// Platform services global setter
void lgx_set_platform_services(lgx_platform_services_t* services);

// Performance counter API functions (Section 5.2)
lgx_result_t lgx_counters_init(void);
lgx_result_t lgx_counters_shutdown(void);
void lgx_increment_builtin_counter(lgx_counter_t counter);
void lgx_add_to_builtin_counter(lgx_counter_t counter, uint64_t value);
uint64_t lgx_get_custom_counter(lgx_custom_counter_t counter);
const char* lgx_get_custom_counter_name(lgx_custom_counter_t counter);

// Chaos testing internal API functions (Section 5.4)
bool lgx_chaos_should_fail_allocation(void);
bool lgx_chaos_should_inject_latency(uint64_t* latency_ns);
void lgx_chaos_inject_latency(void);
bool lgx_chaos_should_hang_gpu(void);
bool lgx_chaos_should_fail_io(void);
void lgx_chaos_get_stats(uint64_t* total_ops, uint64_t* failures, uint64_t* latency_spikes);

// Trace event system internal API functions (Section 4.5)
lgx_result_t lgx_trace_init(void);
lgx_result_t lgx_trace_shutdown(void);

// Namespace isolation API functions (Section 8.1)
lgx_result_t lgx_namespace_create_isolated(void);
lgx_result_t lgx_namespace_mount_libraries(const char* pinned_lib_dir);
lgx_result_t lgx_namespace_validate_versions(void);
lgx_result_t lgx_namespace_cleanup(void);
bool lgx_namespace_is_isolated(void);
void lgx_namespace_get_versions(char* glibc_ver, char* libstdcpp_ver, char* vulkan_ver,
                                size_t buf_size);

// Library manifest API functions (Section 8.2)
lgx_result_t lgx_manifest_check_glibc(char* version_out, size_t version_size,
                                     bool* meets_requirement);
lgx_result_t lgx_manifest_check_libstdcpp(char* version_out, size_t version_size,
                                         bool* meets_requirement);
lgx_result_t lgx_manifest_check_vulkan(char* version_out, size_t version_size,
                                       bool* meets_requirement);
lgx_result_t lgx_manifest_validate_all(void);
void lgx_manifest_get_requirements(char* buffer, size_t buffer_size);

// Input validation API functions (Section 9.1)
bool lgx_validate_pointer(const void* ptr, const char* param_name);
bool lgx_validate_size(size_t size, size_t min_size, size_t max_size, const char* param_name);
bool lgx_validate_allocation_size(size_t size);
bool lgx_validate_alignment(size_t alignment);
bool lgx_validate_string(const char* str, size_t max_length, const char* param_name);
bool lgx_validate_and_truncate_string(const char* src, char* dst, size_t dst_size,
                                     const char* param_name);
bool lgx_validate_path(const char* path, const char* param_name);
bool lgx_validate_enum(int value, int min_value, int max_value, const char* param_name);
bool lgx_validate_buffer(const void* buffer, size_t size, const char* param_name);
bool lgx_validate_struct_size(size_t provided_size, size_t expected_size, const char* struct_name);
bool lgx_validate_capability(lgx_capability_t cap);
bool lgx_validate_log_level(lgx_log_level_t level);
bool lgx_validate_access_pattern(lgx_access_pattern_t pattern);
bool lgx_validate_lifetime(lgx_lifetime_t lifetime);
bool lgx_validate_performance_hint(lgx_performance_hint_t hint);
bool lgx_validate_allocation_intent(const lgx_allocation_intent_base_t* intent);
bool lgx_validate_runtime_config(const lgx_runtime_config_t* config);
void lgx_validation_get_limits(char* buffer, size_t buffer_size);

// Memory safety API functions (Section 9.2)
typedef struct lgx_memory_safety_stats {
    uint64_t total_allocations;
    uint64_t total_frees;
    size_t active_allocations;
    size_t delayed_frees;
    uint64_t canary_violations;
    uint64_t double_free_attempts;
    uint64_t use_after_free_attempts;
    uint32_t current_frame;
} lgx_memory_safety_stats_t;

lgx_result_t lgx_memory_safety_init(void);
lgx_result_t lgx_memory_safety_shutdown(void);
void* lgx_memory_safety_alloc(size_t size);
void lgx_memory_safety_free(void* ptr);
void lgx_memory_safety_advance_frame(void);
void lgx_memory_safety_get_stats(lgx_memory_safety_stats_t* stats);

#ifdef __cplusplus
}
#endif

#endif // LGX_RUNTIME_INTERNAL_H

// ============================================================================
// Resource Limits (Task 14.1)
// ============================================================================

// Resource limits configuration
typedef struct lgx_resource_limits_config {
    size_t max_memory_bytes;           // Maximum memory limit (default: 16GB)
    size_t max_file_handles;           // Maximum file handles (default: 1024)
    size_t max_log_size_bytes;         // Maximum log file size (default: 100MB)
    size_t max_allocations_per_sec;    // Maximum allocations per second (default: 1M)
    const char* log_file_path;         // Log file path (default: /tmp/lgx_runtime.log)
} lgx_resource_limits_config_t;

// Resource limits statistics
typedef struct lgx_resource_limits_stats {
    size_t struct_size;
    
    // Memory stats
    size_t current_memory_bytes;
    size_t peak_memory_bytes;
    size_t max_memory_bytes;
    uint64_t memory_limit_hits;
    
    // File handle stats
    size_t current_file_handles;
    size_t max_file_handles;
    uint64_t file_handle_limit_hits;
    
    // Log stats
    size_t current_log_size_bytes;
    size_t max_log_size_bytes;
    uint64_t log_rotation_count;
    
    // Rate limiting stats
    uint64_t allocation_count;
    size_t max_allocations_per_sec;
    uint64_t rate_limit_violations;
} lgx_resource_limits_stats_t;

// Resource limits API
lgx_result_t lgx_resource_limits_init(const lgx_resource_limits_config_t* config);
lgx_result_t lgx_resource_limits_shutdown(void);

// Memory limit checks
bool lgx_resource_limits_check_memory(size_t size);
void lgx_resource_limits_track_allocation(size_t size);
void lgx_resource_limits_track_deallocation(size_t size);

// Allocation rate limiting
bool lgx_resource_limits_check_allocation_rate(void);

// File handle limits
bool lgx_resource_limits_check_file_handle(void);
void lgx_resource_limits_track_file_open(void);
void lgx_resource_limits_track_file_close(void);

// Log rotation
bool lgx_resource_limits_check_log_rotation(size_t bytes_to_write);
lgx_result_t lgx_resource_limits_rotate_log(void);
void lgx_resource_limits_track_log_write(size_t bytes);

// Statistics
lgx_result_t lgx_resource_limits_get_stats(lgx_resource_limits_stats_t* stats);
lgx_result_t lgx_resource_limits_reset_stats(void);


// ============================================================================
// Memory Protection (Task 14.2)
// ============================================================================

// Memory safety configuration
typedef struct lgx_memory_safety_config {
    bool guard_pages_enabled;           // Guard pages after allocations (debug builds)
    bool canaries_enabled;              // Memory canaries to detect corruption
    bool delayed_reclamation_enabled;   // 3-frame delayed reclamation
    bool tracking_enabled;              // Allocation tracking (double-free prevention)
    bool secure_wiping_enabled;         // Secure memory wiping on free (optional)
} lgx_memory_safety_config_t;

// Memory safety API
void lgx_memory_safety_secure_wipe(void* ptr, size_t size);
void lgx_memory_safety_set_secure_wiping(bool enabled);
void lgx_memory_safety_get_config(lgx_memory_safety_config_t* config);
void lgx_memory_safety_set_config(const lgx_memory_safety_config_t* config);

